[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/zkreum/solana-barron-analysis/blob/main/solana_barron_analysis_colab.ipynb)

# 🧠 Solana $BARRON Scam Analysis

This repository contains an open-source investigation into the January 2025 rugpull of the fake $BARRON memecoin on Solana.

## 📦 Contents

- `fetch_solana_asset_metrics.py`: Downloaded historical SOL price data (January 2025)
- `analyzers/analyze_sol_price_chart.py`: Visualizes SOL price and flags the rugpull date
- `analyzers/analyze_wallet_helius.py`: Uses Helius API to fetch wallet history (scam wallet)
- `analyzers/parse_inflow_summary_native.py`: Parses transaction inflows into scam wallet
- `analyzers/visualize_inflow_senders.py`: Charts the source wallets & volume
- `output/`: Contains saved `.json` and `.png` analysis outputs

## 🚀 How to Use

Run the notebook on Colab:

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/zkreum/solana-barron-analysis/blob/main/solana_barron_analysis_colab.ipynb)

Or clone the repo and run locally:

```bash
git clone https://github.com/zkreum/solana-barron-analysis.git
cd solana-barron-analysis
pip install -r requirements.txt
python fetch_solana_asset_metrics.py
python analyzers/analyze_sol_price_chart.py
```

## 🧩 Dependencies

See `requirements.txt` or run:

```bash
pip install pandas matplotlib requests
```

## 🏆 Bounty Relevance

This repo leverages:
- ✅ Messari's Asset Metrics API
- ✅ Open-source wallet tracking via Helius API

To provide **actionable insight** on rugpull behavior in the Solana ecosystem.
